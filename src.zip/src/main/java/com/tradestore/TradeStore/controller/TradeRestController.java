package com.tradestore.TradeStore.controller;


import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.hibernate.mapping.Array;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tradestore.TradeStore.entity.TradeStore;
import com.tradestore.TradeStore.errorhandler.TradeStoreException;
import com.tradestore.TradeStore.service.TradeStoreService;

import io.swagger.annotations.ApiModelProperty;

@RestController
@RequestMapping(value = "/")
public class TradeRestController {

	@Autowired
	TradeStoreService tradeStoreService;
	
	@GetMapping(value = "getTrade/{tradeID}")
	public ResponseEntity<Collection<TradeStore>> fetchProduct(@PathVariable(name = "tradeID") String tradeID) {
		ArrayList<TradeStore> tradeStore=new ArrayList<>();
		try { 
			tradeStore = (ArrayList<TradeStore>) tradeStoreService.fetchTrade(tradeID);
		}
		catch(Exception e) {
			return new ResponseEntity<>(null, null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		 return new ResponseEntity<>(tradeStore, HttpStatus.OK);
	}
	
	
	@GetMapping(value = "getAllTrade")
	public ResponseEntity<Collection<TradeStore>> fetchProduct() {
		List<TradeStore> tradeStores;
		try { 
			tradeStores = (List<TradeStore>) tradeStoreService.fetchAllTrade();
		}
		catch(Exception e) {
			return new ResponseEntity<>(null, null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		 return new ResponseEntity<>(tradeStores, HttpStatus.OK);
	}
	
	@GetMapping(value = "addTrade/{tradeID}/{version}/{CounterPartyID}/{BookID}/{CreatedDate}/{MaturityDate}")
	public ResponseEntity<TradeStore> addProduct(@PathVariable(name="tradeID")String tradeID,@PathVariable(name="version")int version,
			@PathVariable(name="CounterPartyID")String counterPartyID,@PathVariable(name="BookID")String bookID,@PathVariable(name="CreatedDate")@DateTimeFormat(iso=DateTimeFormat.ISO.DATE)String createdDate,
			@PathVariable(name="MaturityDate")@DateTimeFormat(iso=DateTimeFormat.ISO.DATE)String maturityDate) throws TradeStoreException {
		
			LocalDate createdDateNew=LocalDate.parse(createdDate,DateTimeFormatter.ISO_DATE);
			LocalDate maturityDateNew=LocalDate.parse(maturityDate,DateTimeFormatter.ISO_DATE);
			
			TradeStore tradeStore1 =  tradeStoreService.addTrade(new TradeStore(tradeID, version, counterPartyID, bookID, maturityDateNew, createdDateNew));
		
		return new ResponseEntity<>(tradeStore1, HttpStatus.OK);
	}
	
}

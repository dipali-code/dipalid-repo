package com.tradestore.TradeStore.constants;

public interface TradeExceptionConstants {
	public static final String Reject_Trade_Exception="Lower Version received by Trade";
	public static final String Maturity_Date_IsLessThan_TodayDate="Maturity Date can not be less than Today's Date";
}

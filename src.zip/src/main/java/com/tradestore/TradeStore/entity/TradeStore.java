package com.tradestore.TradeStore.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name = "TradeStore")
public class TradeStore {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	Long id;
	
	@Override
	public String toString() {
		return "TradeStore [id=" + id + ", tradeID=" + tradeID + ", version=" + version + ", counterPartyID="
				+ counterPartyID + ", bookID=" + bookID + ", maturityDate=" + maturityDate + ", createdDate="
				+ createdDate + ", expired=" + expired + "]";
	}

	@NotNull
	@Column(name = "TradeID")
	String tradeID;
	
	public TradeStore() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TradeStore(@NotNull String tradeID, @NotNull Integer version, String counterPartyID, String bookID,
			LocalDate maturityDate, LocalDate createdDate) {
		super();
		this.tradeID = tradeID;
		this.version = version;
		this.counterPartyID = counterPartyID;
		this.bookID = bookID;
		this.maturityDate = maturityDate;
		this.createdDate = createdDate;
	}

	@NotNull
	@Column(name = "Version")
	Integer version;
	
	@Column(name = "CounterPartyID")
	String counterPartyID;
	
	@Column(name = "BookID")
	String bookID;
	
	//@NotNull
	@Column(name = "MaturityDate")
	LocalDate maturityDate;
	
	//@NotNull
	@Column(name = "CreatedDate")
	LocalDate createdDate;
	
	
	@Column(name = "Expired")
	String expired;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTradeID() {
		return tradeID;
	}

	public void setTradeID(String tradeID) {
		this.tradeID = tradeID;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getCounterPartyID() {
		return counterPartyID;
	}

	public void setCounterPartyID(String counterPartyID) {
		this.counterPartyID = counterPartyID;
	}

	public String getBookID() {
		return bookID;
	}

	public void setBookID(String bookID) {
		this.bookID = bookID;
	}

	public LocalDate getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(LocalDate maturityDateNew) {
		this.maturityDate = maturityDateNew;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDateNew) {
		this.createdDate = createdDateNew;
	}

	public String getExpired() {
		return expired;
	}

	public void setExpired(String string) {
		this.expired = string;
	}

	
}

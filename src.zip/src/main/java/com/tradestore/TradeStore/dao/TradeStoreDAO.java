package com.tradestore.TradeStore.dao;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tradestore.TradeStore.dao.mapper.TradeStoreRepo;
import com.tradestore.TradeStore.entity.TradeStore;


@Component
public class TradeStoreDAO {
	
	@Autowired
	TradeStoreRepo tradeStoreRepo; 

	public Collection<TradeStore> fetchTrade(String tradeID) {
		return tradeStoreRepo.fetchTrade(tradeID);
	}
	
	public Collection<TradeStore> fetchAllTrade() {
		return tradeStoreRepo.fetchAllTrade();
	}
	
	public TradeStore addTrade(TradeStore tradeStore) {
		return tradeStoreRepo.save(tradeStore);
	}
}

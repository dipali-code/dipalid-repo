package com.tradestore.TradeStore.dao.mapper;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tradestore.TradeStore.entity.TradeStore;

@EnableJpaRepositories
@Repository
public interface TradeStoreRepo extends JpaRepository<TradeStore, String> {

	@Query("SELECT trade FROM TradeStore trade WHERE trade.tradeID=:tradeID")
	public Collection<TradeStore> fetchTrade(@Param("tradeID") String tradeID);
	
	@Query("SELECT trade FROM TradeStore trade")
	public Collection<TradeStore> fetchAllTrade();
	
	

	
}

package com.tradestore.TradeStore.serviceImpl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tradestore.TradeStore.constants.TradeExceptionConstants;
import com.tradestore.TradeStore.dao.TradeStoreDAO;
import com.tradestore.TradeStore.entity.TradeStore;
import com.tradestore.TradeStore.errorhandler.TradeStoreException;
import com.tradestore.TradeStore.service.TradeStoreService;

@Service
public class TradeStoreIServiceImpl implements TradeStoreService {

	@Autowired
	TradeStoreDAO tradeStoreDAO;


	@Override
	public Collection<TradeStore> fetchTrade(String tradeID) {
		// TODO Auto-generated method stub
		return tradeStoreDAO.fetchTrade(tradeID);
	}

	@Override
	public Collection<TradeStore> fetchAllTrade() {
		// TODO Auto-generated method stub
		ArrayList<TradeStore> tradeList = new ArrayList<TradeStore>();
		tradeList = (ArrayList<TradeStore>) tradeStoreDAO.fetchAllTrade();
		Comparator<TradeStore> comparator=(tradeStore1,tradeStore2)->tradeStore1.getTradeID().compareTo(tradeStore2.getTradeID());
		Collections.sort(tradeList, comparator);
		return tradeList;
	}

	@Override
	@Transactional
	public TradeStore addTrade(TradeStore tradeStore) throws TradeStoreException {
		// TODO Auto-generated method stub
		Collection<TradeStore> tradeFromDB = new ArrayList<>();
		LocalDate todayLocalDate = java.time.LocalDate.now();
		Date todayDate = Date.from(todayLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
		Date maturityDateOfTrade=Date.from(tradeStore.getMaturityDate().atStartOfDay(ZoneId.systemDefault()).toInstant());

		if (Objects.nonNull(tradeStore) && Objects.nonNull(tradeStore.getVersion())) {
			tradeFromDB = fetchTrade(tradeStore.getTradeID());
			if (maturityDateOfTrade.compareTo(todayDate) == -1) {
				throw new TradeStoreException(TradeExceptionConstants.Maturity_Date_IsLessThan_TodayDate);
				
			}
			else
			{
				tradeStore.setExpired("N");
			}
			for (TradeStore trade : tradeFromDB) {
				if (tradeStore.getVersion() < trade.getVersion()) {
					throw new TradeStoreException(TradeExceptionConstants.Reject_Trade_Exception);
				}
				if(tradeStore.getVersion() == trade.getVersion()&& tradeStore.getTradeID().equals(trade.getTradeID())) {
					trade.setBookID(tradeStore.getBookID());
					trade.setCounterPartyID(tradeStore.getCounterPartyID());
					trade.setCreatedDate(tradeStore.getCreatedDate());
					trade.setMaturityDate(tradeStore.getMaturityDate());
					trade.setExpired(tradeStore.getExpired());
					
					return tradeStoreDAO.addTrade(trade);
				}
			}
			

			return tradeStoreDAO.addTrade(tradeStore);

		}

		return null;
	}

	
}

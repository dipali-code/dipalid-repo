package com.tradestore.TradeStore.service;

import java.util.Collection;

import com.tradestore.TradeStore.entity.TradeStore;
import com.tradestore.TradeStore.errorhandler.TradeStoreException;

public interface TradeStoreService {

	Collection<TradeStore> fetchTrade(String tradeID);
	
	Collection<TradeStore> fetchAllTrade();
	
	TradeStore addTrade(TradeStore tradeStore) throws TradeStoreException;
}

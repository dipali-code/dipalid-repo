package com.tradestore.TradeStore.errorhandler;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
public class CustomExceptionHandler  extends ResponseEntityExceptionHandler{
	 
	//@Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(Exception ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> details = new ArrayList<String>();
        for(ObjectError error : ((BindException) ex).getBindingResult().getAllErrors()) {
            details.add(error.getDefaultMessage());
            ConcurrentHashMap c=null;
            
        }
        ErrorResponse error = new ErrorResponse("Validation Failed", details);
        error.setMessage(ex.getMessage());
        return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
    }

}

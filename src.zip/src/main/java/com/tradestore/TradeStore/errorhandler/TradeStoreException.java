package com.tradestore.TradeStore.errorhandler;

public class TradeStoreException extends Exception {

	
	public TradeStoreException(String exceptionMessage) {
		super(exceptionMessage);
	}
}

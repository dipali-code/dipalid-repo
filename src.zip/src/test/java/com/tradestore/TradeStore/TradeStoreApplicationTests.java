package com.tradestore.TradeStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.tradestore.TradeStore;

import java.util.ArrayList;
import java.util.Collection;


import org.h2.command.dml.MergeUsing.When;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.tradestore.TradeStore.dao.TradeStoreDAO;
import com.tradestore.TradeStore.entity.TradeStore;
import com.tradestore.TradeStore.errorhandler.TradeStoreException;
import com.tradestore.TradeStore.service.TradeStoreService;
import com.tradestore.TradeStore.serviceImpl.TradeStoreIServiceImpl;

@RunWith(SpringRunner.class)
public class TradeStoreServiceTest {

	@Mock
	TradeStoreDAO tradeStoreDAO;
	
	@InjectMocks
	TradeStoreService tradeStoreService=Mockito.mock(TradeStoreIServiceImpl.class);
	
	@Test
	public void fetchTradeTest() {
		Collection<TradeStore> tradeStoresByDAO=new ArrayList<TradeStore>();
		TradeStore tradeStore=new TradeStore();
		tradeStore.setTradeID("T1");
		tradeStore.setVersion(1);
		tradeStoresByDAO.add(tradeStore);
		
		Mockito.doReturn(tradeStoresByDAO).when(tradeStoreDAO).fetchTrade("T1");
		Collection<TradeStore> tradeStores=tradeStoreService.fetchTrade("T1");
		Assert.assertNotNull(tradeStores);
	}
	
	@Test
	public void fetchAllTradeTest() {
		Collection<TradeStore> tradeStoresByDAO=new ArrayList<TradeStore>();
		TradeStore tradeStore=new TradeStore();
		tradeStore.setTradeID("T1");
		tradeStore.setVersion(1);
		tradeStoresByDAO.add(tradeStore);
		
		Mockito.doReturn(tradeStoresByDAO).when(tradeStoreDAO).fetchAllTrade();
		Collection<TradeStore> tradeStores=tradeStoreService.fetchAllTrade();
		Assert.assertNotNull(tradeStores);
	}
	
	@Test
	public void addTradeTest(){
		TradeStore tradeStore=new TradeStore();
		tradeStore.setTradeID("T1");
		tradeStore.setBookID("123");
		tradeStore.setCounterPartyID("C1");
		tradeStore.setVersion(1);
		TradeStore tradeStoreNew=new TradeStore();
		
		Mockito.doReturn(tradeStore).when(tradeStoreDAO).addTrade(tradeStore);
		try {
			TradeStore tradeStores=tradeStoreService.addTrade(tradeStore);
		} catch (TradeStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertTrue(tradeStore.getTradeID().equals("T1"));
		Assert.assertTrue(tradeStore.getBookID().equals("123"));
		Assert.assertTrue(tradeStore.getCounterPartyID().equals("C1"));
		Assert.assertTrue(tradeStore.getVersion().equals(1));
	}
}
